#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include"merge.h"
 int main()
{
    long long int n=20,size=10000;
    while(n--)
    {
 
    long long int a[size];
    for(long long int i=0;i<size;i++)
    {
     a[i]=rand();
    }
        clock_t t; 
    t = clock();
   mergeSort(a, 0,size);
    t = clock() - t; 
    double time_taken = ((double)t)/CLOCKS_PER_SEC;
        FILE *fp;
    char file2[]="file2.txt";
    fp=fopen(file2,"a");
 fprintf(fp,"%lld \t",size ); 
fprintf(fp,"%f\n ",time_taken); 
    
    
    printArray(a,size);
    size+=5000;
    }
    return 0;
}