#include<stdio.h>


void mergeSort(long long int a[],long long int m,long long int n);
void printArray(long long int a[],long long int n);