#include"quick.h"
#include<stdio.h>
long long int count=0;
void swap(long long  int* a, long long int* b) 
{ 
    long long int t = *a; 
    *a = *b; 
    *b = t; 
} 

long long int partition (long long int a[], long long int low, long long int high) 
{ 
    long long int pivot = a[high];    
    long long int i = (low - 1);  
  
    for (long long int j = low; j <= high- 1; j++) 
    { 
       
        if (a[j] < pivot) 
        { count++;
            i++;    
            swap(&a[i], &a[j]); 
        } 
    } 
    swap(&a[i + 1], &a[high]); 
    return (i + 1); 
} 

void quicksort(long long int a[], long long int low, long long int high) 
{ 
    if (low < high) 
    { 
  
        long long int pi = partition(a, low, high); 
   
        quicksort(a, low, pi - 1); 
        quicksort(a, pi + 1, high); 
    } 
} 
void print(long long int a[], long long int n)
{
        FILE *fp;
    char file1[]="file1.txt";
    fp=fopen(file1,"a");
 fprintf(fp," %lld \t",n ); 
fprintf(fp," %lld\n ",count); 
 fclose(fp);

}
  