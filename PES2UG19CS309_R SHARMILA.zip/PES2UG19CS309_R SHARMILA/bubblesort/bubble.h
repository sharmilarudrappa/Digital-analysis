#include<stdio.h>
void bubbleSort(long long int arr[],long long int n1);
void printArray(long long int arr[],long long int n2);