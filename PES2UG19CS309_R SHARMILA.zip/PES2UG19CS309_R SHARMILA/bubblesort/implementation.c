#include"bubble.h"
long long count=0;
void swap(long long int *xp,long long  int *yp)  
{  
   long long int temp = *xp;  
    *xp = *yp;  
    *yp = temp;  
}  

void bubbleSort(long long int arr[],long long  int n)  
{  
    long long int i, j;  
    for (i = 0; i < n-1; i++)   
    {   
       
    for (j = 0; j < n-i-1; j++)  
    {
        if (arr[j] > arr[j+1])
             count++;  
            swap(&arr[j], &arr[j+1]);  
}  
    }
}


void printArray(long long int a[], long long int n)
{
        FILE *fp;
    char file1[]="file1.txt";
    fp=fopen(file1,"a");
 fprintf(fp," %lld \t",n ); 
fprintf(fp," %lld\n ",count); 
 fclose(fp);

}
  