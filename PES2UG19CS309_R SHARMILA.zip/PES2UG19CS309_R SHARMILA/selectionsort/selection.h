#include<stdio.h>
void selectionsort(long long int a[],long long int n);
void printArray(long long int arr[],long long int n1);