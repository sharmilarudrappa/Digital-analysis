#include"selection.h"
#include<stdio.h>
long long int count=0;
void swap(long long int *xp, long long int *yp) 
{ 
    long long int temp = *xp; 
    *xp = *yp; 
    *yp = temp; 
} 
  
void selectionsort(long long int a[], long long int n) 
{ 
    long long int i, j, min_idx; 
  

    for (i = 0; i < n-1; i++) 
    { 
    
        min_idx = i; 
        for (j = i+1; j < n; j++) 
          if (a[j] < a[min_idx]) 
            {count++;
            min_idx = j; 
            }
            swap(&a[min_idx], &a[i]); 
            
    } 
} 
void print(long long int a[], long long int n)
{
        FILE *fp;
    char file1[]="file1.txt";
    fp=fopen(file1,"a");
 fprintf(fp,"%lld\t",n); 
fprintf(fp,"%lld\n ",count); 

    fclose(fp);

}
  