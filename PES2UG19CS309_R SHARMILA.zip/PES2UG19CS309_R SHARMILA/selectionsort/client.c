#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include"selection.h"
 int main()
{
     long long int n=20,size=10000;
 //       printf("enter the array size\n");
 //   scanf("%d",&n);
     while(n--)
     {
 
    long long int a[size];
    for(long long int i=0;i<size;i++)
    {
     a[i]=rand();
    }
        clock_t t; 
    t = clock();
   selectionsort(a,size);
    t = clock() - t; 
    double time_taken = ((double)t)/CLOCKS_PER_SEC;
        FILE *fp;
    char file2[]="file2.txt";
    fp=fopen(file2,"a");
 fprintf(fp,"%lld\t",size); 
fprintf(fp,"%f\n ",time_taken); 
    
    
    print(a,size);   
    size+=5000;
     }
     return 0;
}